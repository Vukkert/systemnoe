﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace дз_3
{
    class Program
    {
        static void Main(string[] args)
        {
            double R, S, L;
            Console.WriteLine("Введите радиус окружности R:");
            R = double.Parse(Console.ReadLine());
            L = Math.PI * R;
            S = Math.PI * (R * R);
            Console.WriteLine("L=" + L); Console.WriteLine("S=" + S);
            Console.ReadKey();
        }
    }
}
