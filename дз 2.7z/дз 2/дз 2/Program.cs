﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace дз_2
{
    class Program
    {
        static void Main(string[] args)
        {
            double x1, y1, x2, y2, x3, y3, P, S, A, B, C;
            Console.WriteLine("Введите координаты x1, y1, x2, y2, x3 и y3:");
            x1 = double.Parse(Console.ReadLine()); y1 = double.Parse(Console.ReadLine()); x2 = double.Parse(Console.ReadLine()); y2 = double.Parse(Console.ReadLine()); x3 = double.Parse(Console.ReadLine()); y3 = double.Parse(Console.ReadLine());
            A = Math.Sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
            B = Math.Sqrt((x3 - x2) * (x3 - x2) + (y3 - y2) * (y3 - y2));
            C = Math.Sqrt((x1 - x3) * (x1 - x3) + (y1 - y3) * (y1 - y3));
            P = A + B + C;
            S = Math.Sqrt((P / 2) * ((P / 2) - A) * ((P / 2) - B) * ((P / 2) - C));
            if (S <= 0)
            { Console.WriteLine("Ошибка. Введены неверные координаты."); }
            else { Console.WriteLine("P=" + P); Console.WriteLine("S=" + S); }
            Console.ReadKey();
        }
    }
}
